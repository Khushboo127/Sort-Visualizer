# Sorting Visualizer

**A static website for visualizing different comparison based sorting algorithms.**

[Website Link](https://mahfuzrifat7.github.io/SortingVisualizer "Sorting Visualizer")